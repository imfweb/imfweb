
import { PlatformType, Vehicle, TelemetryData, Detection } from '../types';

// Initial positions for the IMF Fleet
const initialVehicles = [
  { id: 'imf-vtol', name: 'IMF VTOL', type: PlatformType.VTOL, lat: 34.0522, lng: -118.2437, alt: 150, heading: 45 },
  { id: 'imf-quad', name: 'IMF QUAD', type: PlatformType.QUAD, lat: 34.0560, lng: -118.2480, alt: 60, heading: 270 },
  { id: 'imf-usv',  name: 'IMF USV',  type: PlatformType.USV,  lat: 34.0490, lng: -118.2520, alt: 0, heading: 180 }, // Surface
  { id: 'imf-rov',  name: 'IMF ROV',  type: PlatformType.ROV,  lat: 34.0480, lng: -118.2510, alt: -15, heading: 90 }  // Underwater
];

// State storage
let vehiclesState = initialVehicles.map(v => ({
  ...v,
  battery: 100 - Math.random() * 10,
  speed: 0,
  armed: true, 
  mode: 'LOITER'
}));

export const getFleetTelemetry = (dt: number): Vehicle[] => {
  return vehiclesState.map(v => {
    // 1. Physics update
    if (v.armed) {
      v.battery = Math.max(0, v.battery - (dt * 0.015));
      
      // Circle behavior
      v.heading = (v.heading + (v.type === PlatformType.VTOL ? 1 : 4) * dt) % 360;
      
      // Different speeds for different types
      let targetSpeed = 0;
      switch(v.type) {
        case PlatformType.VTOL: targetSpeed = 24; break;
        case PlatformType.QUAD: targetSpeed = 12; break;
        case PlatformType.USV: targetSpeed = 8; break;
        case PlatformType.ROV: targetSpeed = 2; break;
      }
      v.speed = targetSpeed;

      const earthRadius = 6378137;
      const dLat = (v.speed * Math.cos(v.heading * Math.PI / 180) * dt) / earthRadius;
      const dLng = (v.speed * Math.sin(v.heading * Math.PI / 180) * dt) / (earthRadius * Math.cos(v.lat * Math.PI / 180));
      
      v.lat += dLat * (180 / Math.PI);
      v.lng += dLng * (180 / Math.PI);

      // Altitude Bobbing
      if (v.type === PlatformType.VTOL || v.type === PlatformType.QUAD) {
         v.alt += Math.sin(Date.now() / 2000) * 0.2;
      } else if (v.type === PlatformType.USV) {
         v.alt = Math.sin(Date.now() / 800) * 0.5; // Waves
      } else if (v.type === PlatformType.ROV) {
         v.alt = -15 + Math.sin(Date.now() / 3000) * 0.5; // Depth hold
      }
    }

    // 2. Map to TelemetryData
    const telemetry: TelemetryData = {
      latitude: v.lat,
      longitude: v.lng,
      altitude: v.alt,
      heading: v.heading,
      speed: v.speed,
      roll: v.type === PlatformType.USV ? Math.sin(Date.now() / 800) * 5 : Math.sin(Date.now() / 1000) * 2,
      pitch: v.type === PlatformType.USV ? Math.cos(Date.now() / 800) * 3 : Math.cos(Date.now() / 1500) * 2,
      yaw: v.heading,
      batteryVoltage: 22.4 * (v.battery / 100),
      batteryPercent: v.battery,
      satellites: v.type === PlatformType.ROV ? 0 : 16,
      rssi: -45 - Math.random() * 10,
      mode: v.mode,
      armed: v.armed,
      timestamp: Date.now()
    };

    return {
      id: v.id,
      name: v.name,
      type: v.type,
      status: v.battery < 20 ? 'WARN' : 'ONLINE',
      telemetry
    };
  });
};

export const generateDetections = (timestamp: number): Detection[] => {
  const now = Date.now();
  if (Math.floor(now / 4000) % 2 === 0) {
    return [
      {
        id: `det-${now}`,
        label: 'TARGET',
        confidence: 0.92,
        bbox: [0.45 + Math.sin(now/2000) * 0.05, 0.4, 0.1, 0.1], 
        timestamp
      }
    ];
  }
  return [];
};
