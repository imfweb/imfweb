
import React from 'react';
import { Vehicle, PlatformType } from '../types';
import { Plane, Cpu, Anchor, Navigation, Battery, Wifi, Activity } from 'lucide-react';

interface VehicleListProps {
  vehicles: Vehicle[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export const VehicleList: React.FC<VehicleListProps> = ({ vehicles, selectedId, onSelect }) => {
  
  const getIcon = (type: PlatformType) => {
    switch(type) {
      case PlatformType.VTOL: return <Plane className="w-4 h-4" />;
      case PlatformType.QUAD: return <Cpu className="w-4 h-4" />;
      case PlatformType.USV: return <Navigation className="w-4 h-4" />;
      case PlatformType.ROV: return <Anchor className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900 border border-zinc-800 rounded-sm select-none">
      <div className="px-2 py-1.5 bg-black border-b border-zinc-800 flex justify-between items-center">
        <span className="text-[10px] font-bold text-zinc-500 uppercase">Fleet Status</span>
        <div className="flex gap-1">
           <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
           <span className="text-[10px] text-zinc-400 font-mono">{vehicles.length} ACTIVE</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-1 space-y-1">
        {vehicles.map(v => {
          const isSelected = v.id === selectedId;
          const battColor = v.telemetry.batteryPercent < 30 ? 'text-red-500' : 'text-emerald-500';
          const battBarColor = v.telemetry.batteryPercent < 30 ? 'bg-red-500' : 'bg-emerald-500';

          return (
            <button
              key={v.id}
              onClick={() => onSelect(v.id)}
              className={`w-full text-left p-2 rounded-sm border transition-all relative overflow-hidden group ${
                isSelected 
                  ? 'bg-zinc-800 border-blue-500/50 shadow-[inset_0_0_10px_rgba(59,130,246,0.1)]' 
                  : 'bg-black border-zinc-800 hover:border-zinc-600'
              }`}
            >
              {/* Selection Marker */}
              {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500"></div>}

              <div className="flex items-center justify-between mb-2 pl-2">
                <div className="flex items-center gap-2">
                    <span className={`${isSelected ? 'text-blue-400' : 'text-zinc-500'}`}>
                        {getIcon(v.type)}
                    </span>
                    <span className={`text-xs font-bold font-mono ${isSelected ? 'text-white' : 'text-zinc-400'}`}>
                        {v.name}
                    </span>
                </div>
                <div className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${v.status === 'WARN' ? 'bg-red-900/30 text-red-500' : 'bg-emerald-900/20 text-emerald-500'}`}>
                    {v.status}
                </div>
              </div>

              {/* Mini Telemetry Grid */}
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 pl-2 text-[10px] font-mono text-zinc-500">
                  <div className="flex items-center justify-between">
                     <span className="flex items-center gap-1"><Battery className="w-3 h-3" /> BAT</span>
                     <span className={battColor}>{v.telemetry.batteryPercent.toFixed(0)}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                     <span className="flex items-center gap-1"><Wifi className="w-3 h-3" /> LNK</span>
                     <span className="text-blue-400">98%</span>
                  </div>
                  <div className="flex items-center justify-between">
                     <span className="flex items-center gap-1"><Activity className="w-3 h-3" /> ALT</span>
                     <span>{v.telemetry.altitude.toFixed(0)}m</span>
                  </div>
                  <div className="flex items-center justify-between">
                     <span className="text-zinc-600">MODE</span>
                     <span className="text-yellow-500">{v.telemetry.mode}</span>
                  </div>
              </div>
              
              {/* Battery Bar Visual */}
              <div className="mt-2 pl-2 h-1 w-full bg-zinc-800 rounded-full overflow-hidden">
                  <div className={`h-full ${battBarColor} transition-all duration-500`} style={{ width: `${v.telemetry.batteryPercent}%` }}></div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
