
import React, { useMemo, useState, useRef } from 'react';
import { Vehicle, PlatformType, Waypoint } from '../types';
import { Navigation, Layers, Map as MapIcon, Crosshair } from 'lucide-react';

interface MapWidgetProps {
  vehicles: Vehicle[];
  selectedId: string;
  missionWaypoints?: Waypoint[];
  isMissionEditing?: boolean;
  onAddWaypoint?: (wp: Waypoint) => void;
}

export const MapWidget: React.FC<MapWidgetProps> = ({ 
  vehicles, 
  selectedId, 
  missionWaypoints = [], 
  isMissionEditing = false,
  onAddWaypoint
}) => {
  // Viewport State
  const [viewState, setViewState] = useState({ tilt: 55, rotate: 0, zoom: 1.5 });
  
  // Interaction Refs
  const containerRef = useRef<HTMLDivElement>(null);
  const mapPlaneRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const lastMousePos = useRef({ x: 0, y: 0 });

  // Map Constants for projection
  // X = 50 + (lon - centerLon) * scale
  // Y = 50 - (lat - centerLat) * scale
  const CENTER_LAT = 34.0500;
  const CENTER_LON = -118.2480;
  const MAP_SCALE = 1200;

  // Mouse Handlers for Orbit/Tilt
  const handleMouseDown = (e: React.MouseEvent) => {
    // If in editing mode and clicked on map, likely adding a point, don't drag
    if (isMissionEditing && e.target === mapPlaneRef.current) {
        return; 
    }

    isDragging.current = true;
    lastMousePos.current = { x: e.clientX, y: e.clientY };
    if (containerRef.current) containerRef.current.style.cursor = 'grabbing';
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    
    const dx = e.clientX - lastMousePos.current.x;
    const dy = e.clientY - lastMousePos.current.y;
    
    setViewState(prev => ({
      ...prev,
      rotate: prev.rotate + dx * 0.4, // Sensitivity
      tilt: Math.max(0, Math.min(85, prev.tilt - dy * 0.4)) // Clamp tilt 0-85 deg
    }));
    
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDragging.current = false;
    if (containerRef.current) containerRef.current.style.cursor = isMissionEditing ? 'crosshair' : 'grab';
  };

  const handleWheel = (e: React.WheelEvent) => {
    // Zoom clamping between 0.5x and 4x
    setViewState(prev => ({
        ...prev,
        zoom: Math.max(0.5, Math.min(4, prev.zoom - e.deltaY * 0.001))
    }));
  };

  const handleMapClick = (e: React.MouseEvent) => {
    if (!isMissionEditing || !onAddWaypoint || !mapPlaneRef.current) return;

    // Calculate click position relative to the map plane
    const rect = mapPlaneRef.current.getBoundingClientRect();
    
    // Note: Since the element is 3D transformed, mapping clientX/Y directly to the internal coordinate system 
    // is complex. However, browsers often handle offsetX/Y correctly on the target element even if transformed.
    // If e.target is the map plane directly:
    const xPct = (e.nativeEvent.offsetX / rect.width) * 100;
    const yPct = (e.nativeEvent.offsetY / rect.height) * 100;
    
    // Reverse Projection
    // Lon = ((X - 50) / 1200) + CENTER_LON
    // Lat = CENTER_LAT - ((Y - 50) / 1200)
    
    const lon = ((xPct - 50) / MAP_SCALE) + CENTER_LON;
    const lat = CENTER_LAT - ((yPct - 50) / MAP_SCALE);

    onAddWaypoint({
        id: Date.now().toString(),
        latitude: lat,
        longitude: lon,
        altitude: 50, // Default alt
        order: missionWaypoints.length + 1
    });
  };

  const toggleViewMode = () => {
      setViewState(prev => {
          if (prev.tilt > 0) {
              return { ...prev, tilt: 0, rotate: 0 }; 
          } else {
              return { ...prev, tilt: 55 };
          }
      });
  };

  // Helper to project Lat/Lon to %
  const project = (lat: number, lon: number) => {
     return {
         x: 50 + (lon - CENTER_LON) * MAP_SCALE,
         y: 50 - (lat - CENTER_LAT) * MAP_SCALE
     }
  }

  // Tactical Grid Lines
  const gridLines = useMemo(() => {
    const lines = [];
    for(let i=0; i<20; i++) {
        lines.push(<line key={`v${i}`} x1={`${i*5}%`} y1="0" x2={`${i*5}%`} y2="100%" stroke="rgba(255,255,255,0.05)" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />);
        lines.push(<line key={`h${i}`} x1="0" y1={`${i*5}%`} x2="100%" y2={`${i*5}%`} stroke="rgba(255,255,255,0.05)" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />);
    }
    return lines;
  }, []);

  // Generate Mission Path SVG
  const missionPath = useMemo(() => {
     if (missionWaypoints.length < 2) return null;
     
     const points = missionWaypoints.map(wp => {
         const p = project(wp.latitude, wp.longitude);
         return `${p.x},${p.y}`;
     }).join(' ');

     return (
        <polyline 
            points={points} 
            fill="none" 
            stroke="#facc15" 
            strokeWidth="0.5" 
            strokeDasharray="1 0.5"
            vectorEffect="non-scaling-stroke"
            className="drop-shadow-[0_0_2px_rgba(250,204,21,0.8)]"
        />
     );
  }, [missionWaypoints]);


  return (
    <div 
        ref={containerRef}
        className={`w-full h-full bg-zinc-950 relative overflow-hidden group perspective-container select-none ${isMissionEditing ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
    >
      <style>{`
        .perspective-container {
            perspective: 1200px;
            background: radial-gradient(circle at center, #18181b 0%, #09090b 100%);
        }
        .map-plane {
            transform-style: preserve-3d;
            height: 120%;
            width: 100%;
            position: absolute;
            top: -10%;
            transition: transform 0.05s linear; /* Smooth drag */
        }
      `}</style>

      {/* 1. Tilted 3D Map Plane */}
      <div 
        ref={mapPlaneRef}
        className="map-plane bg-zinc-900 border border-zinc-800 shadow-2xl relative"
        style={{
            transform: `rotateX(${viewState.tilt}deg) rotateZ(${viewState.rotate}deg) scale(${viewState.zoom})`
        }}
        onClick={handleMapClick}
      >
          
          {/* Satellite Texture */}
          <div className="absolute inset-0 z-0 pointer-events-none">
               <img 
                src="https://imgs.search.brave.com/J32Q4_2yq-8Y5oQo_k_gOQf_2go_2go/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvNDgx/NDkwMDYzL3Bob3Rv/L3NhdGVsbGl0ZS12/aWV3LW9mLWVhcnRo/LmpwZz9zPTYxMng2/MTImdz0wJms9MjAm/Yz16dHJ2M2t0X2c5/bWk4Wl92X3ZfMl92/X3ZfMl92X3ZfMl92/X3ZfMl92X3ZfMg" 
                alt="Terrain" 
                className="w-full h-full object-cover grayscale-[0.6] opacity-30 mix-blend-overlay" 
               />
               <div className="absolute inset-0 bg-zinc-900/50"></div>
               {/* Water Area Simulation */}
               <div className="absolute bottom-0 left-0 w-full h-1/3 bg-blue-900/10 blur-xl"></div>
          </div>

          {/* SVG Overlay */}
          <svg className="absolute inset-0 w-full h-full z-10 overflow-visible pointer-events-none">
              {gridLines}
              {missionPath}
          </svg>

          {/* Render Vehicles */}
          {vehicles.map(v => {
              const pos = project(v.telemetry.latitude, v.telemetry.longitude);
              const isSelected = v.id === selectedId;
              
              // Determine depth/style based on type
              const isAir = v.type === PlatformType.VTOL || v.type === PlatformType.QUAD;
              const isUnderwater = v.type === PlatformType.ROV;
              
              // Altitude visuals (Drop line height)
              const altScale = 2; // px per meter
              const dropHeight = isAir ? v.telemetry.altitude * altScale : 0;
              const depthOffset = isUnderwater ? Math.abs(v.telemetry.altitude) * altScale : 0;

              return (
                <div 
                    key={v.id}
                    className="absolute w-0 h-0 flex items-center justify-center transition-all duration-100 ease-linear"
                    style={{ 
                        left: `${pos.x}%`, 
                        top: `${pos.y}%`,
                        zIndex: isSelected ? 50 : 20,
                        transform: `translateZ(${isAir ? dropHeight : -depthOffset}px)`
                    }}
                >
                    {/* 3D Wireframe Dome (Tactical Bubble) */}
                    {isSelected && (
                        <div className="absolute w-[200px] h-[200px] border border-green-500/20 rounded-full animate-pulse pointer-events-none" 
                             style={{ 
                                 transform: 'rotateX(90deg)', 
                                 background: 'radial-gradient(circle, rgba(16,185,129,0.1) 0%, transparent 70%)' 
                             }} 
                        />
                    )}

                    {/* Ground Shadow / Drop Line for Aircraft */}
                    {isAir && (
                        <>
                            <div className="absolute w-2 h-2 bg-black/50 blur-[2px] rounded-full" style={{ transform: `translateY(${dropHeight}px)` }}></div>
                            <div className="absolute w-px bg-green-500/50" style={{ height: dropHeight, transform: `translateY(${dropHeight/2}px)` }}></div>
                        </>
                    )}

                    {/* Vehicle Icon (Billboarded) */}
                    <div 
                        className="relative"
                        style={{ 
                            transform: `rotateZ(${-viewState.rotate}deg) rotateX(${-viewState.tilt}deg)` // Counter-rotate to billboard
                        }}
                    >
                        {/* Label */}
                        <div className={`absolute -top-6 left-1/2 -translate-x-1/2 text-[8px] font-bold whitespace-nowrap px-1 rounded ${isSelected ? 'bg-blue-600 text-white' : 'bg-black/50 text-zinc-300'}`}>
                            {v.name}
                        </div>

                        {/* Icon Shape */}
                        <div className={`w-4 h-4 -translate-x-1/2 -translate-y-1/2 border-2 rounded-sm rotate-45 transition-colors ${isSelected ? 'border-blue-400 bg-blue-500/20' : 'border-zinc-500 bg-black/50'}`}>
                             {/* Heading Indicator */}
                             <div className="absolute top-0 left-0 w-full h-full border-t-2 border-l-2 border-transparent" 
                                  style={{ transform: `rotate(${v.telemetry.heading - 45}deg)` }}>
                                  <div className="absolute -top-1 -left-1 w-1.5 h-1.5 bg-current rounded-full"></div>
                             </div>
                        </div>
                    </div>
                </div>
              );
          })}

          {/* Render Waypoints */}
          {missionWaypoints.map((wp, i) => {
              const pos = project(wp.latitude, wp.longitude);
              return (
                <div 
                    key={wp.id}
                    className="absolute w-0 h-0 flex items-center justify-center z-10"
                    style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                >
                    <div className="w-px h-8 bg-yellow-500/30 absolute bottom-0"></div>
                    <div 
                        className="relative"
                        style={{ transform: `rotateZ(${-viewState.rotate}deg) rotateX(${-viewState.tilt}deg)` }}
                    >
                        <div className="w-4 h-4 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center bg-black/50 border border-yellow-500 text-[8px] font-mono text-yellow-500 rounded-full shadow-lg">
                            {i + 1}
                        </div>
                    </div>
                </div>
              )
          })}
      </div>

      {/* HUD Overlay - Compass & Info */}
      <div className="absolute bottom-4 left-4 z-50 pointer-events-none">
          <div className="w-16 h-16 rounded-full border border-zinc-700 bg-black/40 backdrop-blur flex items-center justify-center relative shadow-xl">
             <Navigation className="w-8 h-8 text-blue-500" style={{ transform: `rotate(${viewState.rotate}deg)` }} />
             <div className="absolute -top-1 text-[8px] font-bold text-zinc-500">N</div>
          </div>
      </div>
      
      {/* View Toggle */}
      <div className="absolute top-4 right-4 z-50 flex flex-col gap-2">
          <button 
            onClick={toggleViewMode}
            className="bg-black/80 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 p-2 rounded-sm shadow-lg backdrop-blur transition-all active:scale-95"
            title="Toggle 2D/3D View"
          >
             {viewState.tilt > 0 ? <Layers className="w-4 h-4 text-blue-400" /> : <MapIcon className="w-4 h-4" />}
          </button>
      </div>

      {/* Controls Hint */}
      <div className="absolute bottom-4 right-4 z-50 text-[9px] text-zinc-500 text-right bg-black/50 px-2 py-1 rounded backdrop-blur pointer-events-none">
         <div>LEFT CLICK + DRAG to ROTATE</div>
         <div>SCROLL to ZOOM</div>
         {isMissionEditing && <div className="text-blue-400 font-bold mt-1">CLICK MAP TO ADD WAYPOINT</div>}
      </div>

    </div>
  );
};
