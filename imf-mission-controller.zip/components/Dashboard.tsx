
import React, { useState, useEffect, useCallback } from 'react';
import { 
  LogOut, 
  Target, 
  Wifi, 
  Radio, 
  ShieldAlert,
  Gamepad2,
  Map as MapIcon
} from 'lucide-react';
import { UserRole, Vehicle, LogEntry, Waypoint } from '../types';
import { getFleetTelemetry, generateDetections } from '../services/simulationService';
import { VideoFeed } from './VideoFeed';
import { TelemetryPanel } from './TelemetryPanel';
import { MapWidget } from './MapWidget';
import { ControlsPanel } from './ControlsPanel';
import { VehicleList } from './VehicleList';
import { MissionPlanner } from './MissionPlanner';

interface DashboardProps {
  userRole: UserRole;
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ userRole, onLogout }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('imf-vtol');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  // Mission State
  const [rightPanelTab, setRightPanelTab] = useState<'controls' | 'mission'>('controls');
  const [waypoints, setWaypoints] = useState<Waypoint[]>([]);
  const [isMissionEditing, setIsMissionEditing] = useState(false);

  // Derived selected vehicle data
  const selectedVehicle = vehicles.find(v => v.id === selectedVehicleId) || vehicles[0];

  // Simulation Loop
  useEffect(() => {
    const interval = setInterval(() => {
      const dt = 0.1; // 100ms delta
      const fleetData = getFleetTelemetry(dt);
      setVehicles(fleetData);
    }, 100);

    return () => clearInterval(interval);
  }, []);

  const addLog = useCallback((message: string, level: LogEntry['level'] = 'INFO') => {
    setLogs(prev => [{
      id: Date.now().toString(),
      timestamp: Date.now(),
      level,
      message
    }, ...prev].slice(0, 50));
  }, []);

  const handleArmToggle = () => {
    if (selectedVehicle) {
      addLog(`TOGGLE ARM CMD: ${selectedVehicle.name}`, 'WARN');
    }
  };

  // Sync edit mode with tab
  useEffect(() => {
    if (rightPanelTab !== 'mission') {
        setIsMissionEditing(false);
    }
  }, [rightPanelTab]);

  return (
    <div className="flex flex-col h-screen w-full bg-zinc-950 text-zinc-300 font-mono select-none overflow-hidden">
      
      {/* Top Industrial Header */}
      <header className="h-12 bg-zinc-900 border-b-2 border-zinc-800 flex items-center justify-between px-2 shrink-0 shadow-lg z-10">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-2 border-r border-zinc-700 pr-4">
             <div className="w-6 h-6 bg-blue-700 rounded-sm flex items-center justify-center shadow-[0_0_10px_rgba(29,78,216,0.5)]">
                <Target className="w-4 h-4 text-white" />
             </div>
             <div>
                <h1 className="text-sm font-bold tracking-tight text-white leading-none">IMF<span className="text-blue-500">_CMD</span></h1>
                <div className="text-[10px] text-zinc-500 leading-none">FLEET_COMMAND</div>
             </div>
          </div>
          
          <div className="hidden md:flex items-center gap-2">
              <span className="text-[10px] text-zinc-600 font-bold">ACTIVE MISSION:</span>
              <span className="text-xs text-blue-400 font-bold tracking-wider">OPERATION_SKY_EYE</span>
          </div>
        </div>

        {/* Global Status Indicators */}
        <div className="flex items-center gap-2">
            <div className="flex items-center gap-4 bg-black/40 px-3 py-1 rounded-sm border border-zinc-800">
               <div className="flex items-center gap-2">
                  <Wifi className="w-3 h-3 text-emerald-500" />
                  <span className="text-xs text-emerald-500 font-bold">LINK: 98%</span>
               </div>
               <div className="w-px h-3 bg-zinc-700"></div>
               <div className="flex items-center gap-2">
                  <Radio className="w-3 h-3 text-blue-500" />
                  <span className="text-xs text-blue-500 font-bold">LTE: 4G</span>
               </div>
            </div>

            <div className="h-8 w-px bg-zinc-800 mx-1" />
            
            <div className="flex flex-col items-end mr-2">
                <div className="text-[10px] text-zinc-500">OPERATOR</div>
                <div className="text-xs font-bold text-zinc-200">{userRole}</div>
            </div>
            
            <button onClick={onLogout} className="p-2 bg-red-900/20 text-red-500 hover:bg-red-900/40 border border-red-900/50 rounded-sm transition-colors">
               <LogOut className="w-4 h-4" />
            </button>
        </div>
      </header>

      {/* Main Grid Layout */}
      <div className="flex-1 p-2 gap-2 flex overflow-hidden relative z-0">
        
        {/* Left Column: Telemetry & PFD */}
        <div className="w-72 xl:w-80 flex flex-col gap-2 shrink-0">
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm p-1 flex items-center justify-between">
                <span className="text-[10px] font-bold text-zinc-500 px-2">PRIMARY_FLIGHT_DISPLAY</span>
                <span className="text-[10px] font-bold text-blue-500">{selectedVehicle?.name}</span>
            </div>
            <div className="flex-1 overflow-y-auto overflow-x-hidden bg-black/20 rounded-sm border border-zinc-800/50">
                <TelemetryPanel data={selectedVehicle?.telemetry || null} />
            </div>
        </div>

        {/* Center Column: Vision & Map */}
        <div className="flex-1 flex flex-col gap-2 min-w-0">
             {/* Top: Video Feed */}
             <div className="flex-[4] relative border-2 border-zinc-800 bg-black rounded-sm overflow-hidden group">
                 {/* Corner markers */}
                 <div className="absolute top-0 left-0 w-8 h-8 border-l-2 border-t-2 border-zinc-600 z-20"></div>
                 <div className="absolute top-0 right-0 w-8 h-8 border-r-2 border-t-2 border-zinc-600 z-20"></div>
                 <div className="absolute bottom-0 left-0 w-8 h-8 border-l-2 border-b-2 border-zinc-600 z-20"></div>
                 <div className="absolute bottom-0 right-0 w-8 h-8 border-r-2 border-b-2 border-zinc-600 z-20"></div>
                 
                 <VideoFeed 
                    detections={generateDetections(Date.now())} 
                    telemetry={selectedVehicle?.telemetry || null} 
                    platform={selectedVehicle?.type} 
                 />
             </div>

             {/* Bottom: Map */}
             <div className="flex-[3] relative border-2 border-zinc-800 bg-zinc-900 rounded-sm overflow-hidden">
                <MapWidget 
                    vehicles={vehicles} 
                    selectedId={selectedVehicleId} 
                    missionWaypoints={waypoints}
                    isMissionEditing={isMissionEditing}
                    onAddWaypoint={(wp) => {
                        setWaypoints(prev => [...prev, wp]);
                        addLog(`Added WP${wp.order}: ${wp.latitude.toFixed(4)}, ${wp.longitude.toFixed(4)}`, 'INFO');
                    }}
                />
             </div>
        </div>

        {/* Right Column: Fleet List, Controls & Logs */}
        <div className="w-72 flex flex-col gap-2 shrink-0">
            
            {/* 1. Fleet Status List */}
            <div className="flex-[2] min-h-[150px]">
                <VehicleList 
                    vehicles={vehicles} 
                    selectedId={selectedVehicleId} 
                    onSelect={setSelectedVehicleId} 
                />
            </div>

            {/* 2. Controls / Mission Switcher */}
            <div className="shrink-0 flex flex-col gap-1">
                {/* Tabs */}
                <div className="flex gap-1">
                    <button 
                        onClick={() => setRightPanelTab('controls')}
                        className={`flex-1 flex items-center justify-center gap-1 py-1.5 text-[10px] font-bold border rounded-t-sm transition-colors ${rightPanelTab === 'controls' ? 'bg-zinc-800 border-zinc-600 text-blue-400' : 'bg-black border-zinc-800 text-zinc-500 hover:bg-zinc-900'}`}
                    >
                        <Gamepad2 className="w-3 h-3" /> COMMAND
                    </button>
                    <button 
                        onClick={() => setRightPanelTab('mission')}
                        className={`flex-1 flex items-center justify-center gap-1 py-1.5 text-[10px] font-bold border rounded-t-sm transition-colors ${rightPanelTab === 'mission' ? 'bg-zinc-800 border-zinc-600 text-blue-400' : 'bg-black border-zinc-800 text-zinc-500 hover:bg-zinc-900'}`}
                    >
                        <MapIcon className="w-3 h-3" /> MISSION
                    </button>
                </div>

                {/* Panel Content */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-b-sm p-1">
                    {rightPanelTab === 'controls' ? (
                        <ControlsPanel 
                            platform={selectedVehicle?.type} 
                            isArmed={selectedVehicle?.telemetry.armed || false} 
                            userRole={userRole}
                            onArmToggle={handleArmToggle}
                            onLog={addLog}
                        />
                    ) : (
                        <MissionPlanner 
                            waypoints={waypoints}
                            onUpdate={setWaypoints}
                            onLog={addLog}
                            isEditing={isMissionEditing}
                            setEditing={setIsMissionEditing}
                        />
                    )}
                </div>
            </div>

            {/* 3. System Log */}
            <div className="flex-1 bg-black border border-zinc-800 rounded-sm flex flex-col overflow-hidden min-h-[100px]">
                <div className="bg-zinc-900 px-2 py-1 border-b border-zinc-800 flex justify-between items-center">
                    <span className="text-[10px] font-bold text-zinc-500">SYS_LOG</span>
                    <ShieldAlert className="w-3 h-3 text-zinc-600" />
                </div>
                <div className="flex-1 p-2 overflow-y-auto font-mono text-[10px] space-y-1">
                    {logs.map((log) => (
                        <div key={log.id} className="flex gap-2 border-l-2 border-zinc-800 pl-1">
                            <span className="text-zinc-600">{new Date(log.timestamp).toLocaleTimeString([], {hour12: false, hour:'2-digit', minute:'2-digit', second:'2-digit'})}</span>
                            <span className={`${
                                log.level === 'WARN' ? 'text-amber-500' :
                                log.level === 'ERROR' ? 'text-red-500' :
                                log.level === 'SUCCESS' ? 'text-green-500' :
                                'text-zinc-400'
                            }`}>
                                {log.message}
                            </span>
                        </div>
                    ))}
                    {logs.length === 0 && <span className="text-zinc-700">System initialized. No events.</span>}
                </div>
            </div>
        </div>

      </div>
      
      {/* Scanline Overlay */}
      <div className="absolute inset-0 scanlines pointer-events-none z-50 opacity-10" />
    </div>
  );
};
