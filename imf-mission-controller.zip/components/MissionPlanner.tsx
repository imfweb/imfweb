
import React from 'react';
import { Waypoint, LogEntry } from '../types';
import { MapPin, Trash2, Upload, Play, Flag, ArrowRight } from 'lucide-react';

interface MissionPlannerProps {
  waypoints: Waypoint[];
  onUpdate: (waypoints: Waypoint[]) => void;
  onLog: (msg: string, level: LogEntry['level']) => void;
  isEditing: boolean;
  setEditing: (editing: boolean) => void;
}

export const MissionPlanner: React.FC<MissionPlannerProps> = ({ 
  waypoints, 
  onUpdate, 
  onLog,
  isEditing,
  setEditing
}) => {

  const handleDelete = (id: string) => {
    onUpdate(waypoints.filter(wp => wp.id !== id));
  };

  const handleClear = () => {
    onUpdate([]);
    onLog('Mission cleared locally', 'INFO');
  };

  const handleUpload = () => {
    if (waypoints.length < 2) {
      onLog('Mission invalid: Need at least 2 points', 'WARN');
      return;
    }
    onLog(`Uploading ${waypoints.length} waypoints to vehicle...`, 'INFO');
    setTimeout(() => {
        onLog('Mission Upload Successful [CRC: 0x4F2A]', 'SUCCESS');
    }, 800);
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900 border border-zinc-800 rounded-sm">
      
      {/* Header / Toolbar */}
      <div className="bg-black p-2 border-b border-zinc-800 flex justify-between items-center">
         <div className="flex items-center gap-2">
            <MapPin className={`w-4 h-4 ${isEditing ? 'text-blue-500 animate-pulse' : 'text-zinc-500'}`} />
            <span className="text-[10px] font-bold text-zinc-300">MISSION_EDITOR</span>
         </div>
         <button 
            onClick={() => setEditing(!isEditing)}
            className={`text-[9px] px-2 py-1 rounded border font-bold transition-all ${isEditing ? 'bg-blue-900/40 border-blue-500 text-blue-400' : 'bg-zinc-800 border-zinc-600 text-zinc-400'}`}
         >
            {isEditing ? 'ADDING POINTS...' : '+ ADD POINTS'}
         </button>
      </div>

      {/* Waypoint List */}
      <div className="flex-1 overflow-y-auto p-1 space-y-1 bg-zinc-950/50">
         {waypoints.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-600 space-y-2 opacity-50">
                <Flag className="w-8 h-8" />
                <span className="text-[10px]">NO WAYPOINTS SET</span>
                <span className="text-[9px]">Click map to add points</span>
            </div>
         ) : (
            waypoints.map((wp, idx) => (
                <div key={wp.id} className="group flex items-center justify-between bg-black border border-zinc-800 p-2 rounded-sm hover:border-zinc-600 transition-colors">
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-zinc-800 text-[9px] font-mono flex items-center justify-center text-blue-400 border border-zinc-700">
                            {idx + 1}
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[9px] font-mono text-zinc-400">
                                LAT: {wp.latitude.toFixed(5)}
                            </span>
                            <span className="text-[9px] font-mono text-zinc-400">
                                LON: {wp.longitude.toFixed(5)}
                            </span>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1 bg-zinc-900 px-1 rounded border border-zinc-800">
                            <ArrowRight className="w-3 h-3 text-zinc-500 rotate-[-45deg]" />
                            <span className="text-[10px] font-mono text-yellow-500">{wp.altitude}m</span>
                        </div>
                        <button onClick={() => handleDelete(wp.id)} className="text-zinc-600 hover:text-red-500">
                            <Trash2 className="w-3 h-3" />
                        </button>
                    </div>
                </div>
            ))
         )}
      </div>

      {/* Action Footer */}
      <div className="p-2 border-t border-zinc-800 bg-zinc-900 grid grid-cols-2 gap-2">
          <button 
            disabled={waypoints.length === 0}
            onClick={handleClear}
            className="flex items-center justify-center gap-1 bg-zinc-800 hover:bg-red-900/30 border border-zinc-700 hover:border-red-800 text-zinc-400 hover:text-red-400 py-2 rounded-sm text-[10px] font-bold transition-all disabled:opacity-50"
          >
             <Trash2 className="w-3 h-3" /> CLEAR
          </button>
          <button 
             disabled={waypoints.length === 0}
             onClick={handleUpload}
             className="flex items-center justify-center gap-1 bg-blue-900/20 hover:bg-blue-900/40 border border-blue-900 hover:border-blue-500 text-blue-500 py-2 rounded-sm text-[10px] font-bold transition-all disabled:opacity-50"
          >
             <Upload className="w-3 h-3" /> UPLOAD
          </button>
      </div>
    </div>
  );
};
