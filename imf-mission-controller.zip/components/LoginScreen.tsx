import React, { useState } from 'react';
import { UserRole } from '../types';
import { Terminal, Lock, ChevronRight } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (role: UserRole) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [bootText, setBootText] = useState<string[]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate boot sequence
    const sequence = [
        "Initializing secure connection...",
        "Handshake established [TLS 1.3]",
        "Verifying credentials...",
        "Loading user profile...",
        "ACCESS GRANTED"
    ];

    let delay = 0;
    sequence.forEach((line, index) => {
        delay += Math.random() * 400 + 200;
        setTimeout(() => {
            setBootText(prev => [...prev, line]);
            if (index === sequence.length - 1) {
                setTimeout(() => {
                    const role = email.includes('admin') ? UserRole.ADMIN : UserRole.PILOT;
                    onLogin(role);
                }, 800);
            }
        }, delay);
    });
  };

  return (
    <div className="h-screen w-full bg-black text-zinc-400 font-mono flex items-center justify-center p-4">
        <div className="w-full max-w-lg border border-zinc-800 bg-zinc-950 p-1 relative shadow-2xl">
            {/* Terminal Header */}
            <div className="bg-zinc-900 border-b border-zinc-800 px-4 py-1 flex justify-between items-center text-xs">
                <span>IMF_SECURE_TERMINAL_V2.4</span>
                <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-zinc-700"></div>
                    <div className="w-2 h-2 rounded-full bg-zinc-700"></div>
                </div>
            </div>

            <div className="p-8 space-y-8">
                <div className="text-center space-y-2">
                    <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 rounded mx-auto flex items-center justify-center">
                        <Terminal className="w-6 h-6 text-emerald-500" />
                    </div>
                    <h1 className="text-xl font-bold text-white tracking-wider">SYSTEM AUTHENTICATION</h1>
                    <div className="text-xs text-zinc-600">ENTER CREDENTIALS TO INITIALIZE UPLINK</div>
                </div>

                {!isLoading ? (
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-zinc-500">USER_ID</label>
                            <input 
                                type="text" 
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full bg-black border border-zinc-700 px-3 py-2 text-emerald-500 focus:outline-none focus:border-emerald-500 transition-colors placeholder:text-zinc-800"
                                placeholder="OPERATOR.ID"
                                autoFocus
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-zinc-500">ACCESS_KEY</label>
                            <input 
                                type="password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full bg-black border border-zinc-700 px-3 py-2 text-emerald-500 focus:outline-none focus:border-emerald-500 transition-colors placeholder:text-zinc-800"
                                placeholder="••••••••"
                            />
                        </div>

                        <button 
                            type="submit" 
                            className="w-full bg-emerald-900/20 border border-emerald-900/50 hover:bg-emerald-900/40 hover:border-emerald-500 text-emerald-500 py-3 mt-4 text-xs font-bold tracking-widest transition-all flex items-center justify-center gap-2 group"
                        >
                            <Lock className="w-3 h-3 group-hover:text-emerald-400" />
                            AUTHENTICATE
                            <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                        </button>
                    </form>
                ) : (
                    <div className="bg-black border border-zinc-800 p-4 h-48 font-mono text-xs overflow-hidden flex flex-col justify-end">
                        {bootText.map((line, i) => (
                            <div key={i} className="mb-1">
                                <span className="text-zinc-600 mr-2">{`>`}</span>
                                <span className={i === bootText.length - 1 ? 'text-emerald-400 animate-pulse' : 'text-zinc-400'}>
                                    {line}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Footer Status */}
            <div className="border-t border-zinc-800 px-4 py-2 text-[10px] text-zinc-600 flex justify-between uppercase">
                <span>Status: WAITING</span>
                <span>Enc: AES-256</span>
            </div>
            
            {/* Corner Deco */}
            <div className="absolute top-0 left-0 w-2 h-2 border-l border-t border-zinc-500"></div>
            <div className="absolute top-0 right-0 w-2 h-2 border-r border-t border-zinc-500"></div>
            <div className="absolute bottom-0 left-0 w-2 h-2 border-l border-b border-zinc-500"></div>
            <div className="absolute bottom-0 right-0 w-2 h-2 border-r border-b border-zinc-500"></div>
        </div>
    </div>
  );
};