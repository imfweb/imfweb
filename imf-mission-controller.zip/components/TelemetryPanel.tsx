
import React from 'react';
import { TelemetryData } from '../types';
import { Compass, ArrowUp, Satellite, SignalHigh } from 'lucide-react';

interface TelemetryPanelProps {
  data: TelemetryData | null;
}

// Visual Signal Strength Indicator
const SignalBars = ({ level, colorClass = "bg-emerald-500" }: { level: number, colorClass?: string }) => (
  <div className="flex items-end gap-0.5 h-2.5 ml-auto opacity-80">
    {[1, 2, 3, 4].map(i => (
      <div 
        key={i} 
        className={`w-0.5 rounded-[1px] ${i <= level ? colorClass : 'bg-zinc-700/30'}`} 
        style={{ height: `${i * 25}%` }}
      />
    ))}
  </div>
);

export const TelemetryPanel: React.FC<TelemetryPanelProps> = ({ data }) => {
  if (!data) return <div className="h-full flex items-center justify-center text-zinc-600 animate-pulse bg-zinc-950 text-xs">NO DATA LINK</div>;

  // Pitch calculation for PFD
  const pitchPx = data.pitch * 4; // Scale pitch to pixels
  const rollDeg = -data.roll;

  // Calculate signal levels
  // GPS: <4 (0), 4-7 (1), 8-10 (2), 11-14 (3), >14 (4)
  const gpsLevel = data.satellites > 14 ? 4 : data.satellites > 10 ? 3 : data.satellites > 7 ? 2 : data.satellites > 3 ? 1 : 0;
  
  // Link: Mocked based on RSSI usually, here just assuming good link for simulation
  const linkLevel = 4; 

  return (
    <div className="flex flex-col h-full bg-black border border-zinc-800 rounded-sm overflow-hidden select-none">
        
        {/* PFD - Primary Flight Display Section */}
        <div className="relative h-56 bg-zinc-800 overflow-hidden group border-b border-zinc-800">
            
            {/* 1. Artificial Horizon Layer */}
            <div 
                className="absolute inset-[-50%] transition-transform duration-100 ease-linear origin-center"
                style={{ transform: `rotate(${rollDeg}deg) translateY(${pitchPx}px)` }}
            >
                {/* Sky */}
                <div className="w-full h-1/2 bg-gradient-to-b from-[#3b82f6] to-[#60a5fa]"></div>
                {/* Ground */}
                <div className="w-full h-1/2 bg-gradient-to-b from-[#854d0e] to-[#713f12]">
                    {/* Grid lines on ground for depth */}
                    <div className="w-full h-full opacity-20" 
                         style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)', backgroundSize: '40px 40px', perspective: '500px' }}></div>
                </div>
                {/* Horizon Line */}
                <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white shadow-md"></div>
            </div>

            {/* 2. Pitch Ladder Overlay */}
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center opacity-70">
                 {/* Center Marker */}
                 <div className="w-40 h-px bg-white/50 mb-4"></div>
                 <div className="w-20 h-px bg-white/50 mb-4"></div>
                 <div className="w-60 h-px bg-yellow-400 shadow-sm"></div> {/* Zero Pitch */}
                 <div className="w-20 h-px bg-white/50 mt-4"></div>
                 <div className="w-40 h-px bg-white/50 mt-4"></div>
            </div>

            {/* 3. Speed Tape (Left) */}
            <div className="absolute top-0 left-0 h-full w-14 bg-black/40 backdrop-blur-sm border-r border-white/20 flex flex-col items-end py-2 pr-1 overflow-hidden">
                <div className="text-[9px] text-zinc-400 font-bold mb-auto">GS</div>
                
                {/* Rolling Tape Simulation */}
                <div className="flex flex-col items-end gap-3 text-white/60 text-xs font-mono my-auto transition-all duration-300">
                    <span className="opacity-50">{(data.speed + 2).toFixed(0)}</span>
                    <span className="opacity-80">{(data.speed + 1).toFixed(0)}</span>
                    <div className="bg-black/60 border border-white text-white font-bold px-1 py-0.5 rounded-sm text-sm scale-110 shadow-lg">
                        {data.speed.toFixed(0)}
                    </div>
                    <span className="opacity-80">{(Math.max(0, data.speed - 1)).toFixed(0)}</span>
                    <span className="opacity-50">{(Math.max(0, data.speed - 2)).toFixed(0)}</span>
                </div>
                
                <div className="mt-auto text-[9px] text-zinc-400">m/s</div>
            </div>

            {/* 4. Altitude Tape (Right) */}
            <div className="absolute top-0 right-0 h-full w-14 bg-black/40 backdrop-blur-sm border-l border-white/20 flex flex-col items-start py-2 pl-1 overflow-hidden">
                <div className="text-[9px] text-zinc-400 font-bold mb-auto">ALT</div>
                
                <div className="flex flex-col items-start gap-3 text-white/60 text-xs font-mono my-auto">
                     <span className="opacity-50">{(data.altitude + 20).toFixed(0)}</span>
                     <span className="opacity-80">{(data.altitude + 10).toFixed(0)}</span>
                     <div className="bg-black/60 border border-white text-white font-bold px-1 py-0.5 rounded-sm text-sm scale-110 shadow-lg">
                        {data.altitude.toFixed(0)}
                    </div>
                     <span className="opacity-80">{(data.altitude - 10).toFixed(0)}</span>
                     <span className="opacity-50">{(data.altitude - 20).toFixed(0)}</span>
                </div>
                
                <div className="mt-auto text-[9px] text-zinc-400">m</div>
            </div>

            {/* 5. Center Fixed Aircraft Reference */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                 <svg width="60" height="20">
                     <path d="M0 10 L20 10 L30 15 L40 10 L60 10" stroke="#facc15" strokeWidth="3" fill="none" strokeLinecap="round" className="drop-shadow-md" />
                 </svg>
            </div>
            
            {/* Top Roll Scale */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 flex gap-2">
                 <div className="w-0.5 h-2 bg-white/50 -rotate-30 origin-bottom"></div>
                 <div className="w-1 h-3 bg-white shadow-sm"></div>
                 <div className="w-0.5 h-2 bg-white/50 rotate-30 origin-bottom"></div>
            </div>
        </div>

        {/* Text Telemetry Grid */}
        <div className="flex-1 bg-zinc-900 grid grid-cols-2 gap-px border-t border-zinc-800">
            <DataCell label="HEADING" value={data.heading.toFixed(0)} unit="DEG" icon={Compass} />
            <DataCell label="CLIMB" value={(Math.random() * 0.5).toFixed(1)} unit="M/S" icon={ArrowUp} />
            
            <DataCell label="BATTERY" value={data.batteryPercent.toFixed(0)} unit="%" color={data.batteryPercent < 30 ? "text-red-500" : "text-emerald-500"} />
            <DataCell label="VOLTAGE" value={data.batteryVoltage.toFixed(1)} unit="V" />
            
            {/* GPS with Signal Bars */}
            <DataCell 
                label="GPS SAT" 
                value={data.satellites} 
                unit="LOCKED" 
                icon={Satellite} 
                extra={<SignalBars level={gpsLevel} colorClass="bg-blue-500" />}
            />
            <DataCell label="HDOP" value="0.6" unit="M" />
            
            {/* Link with Signal Bars */}
            <DataCell 
                label="LINK" 
                value="98" 
                unit="%" 
                icon={SignalHigh} 
                color="text-blue-400" 
                extra={<SignalBars level={linkLevel} colorClass="bg-emerald-500" />}
            />
            <DataCell label="MODE" value={data.mode} unit="" color="text-yellow-400 font-bold" />
        </div>
    </div>
  );
};

const DataCell = ({ label, value, unit, icon: Icon, color = "text-zinc-100", extra }: any) => (
    <div className="bg-black/20 p-2 flex flex-col justify-center border-b border-zinc-800/50 hover:bg-zinc-800 transition-colors relative group">
        <div className="flex items-center justify-between mb-0.5 h-3">
            <div className="flex items-center gap-1.5">
                {Icon && <Icon className="w-3 h-3 text-zinc-500 group-hover:text-zinc-300 transition-colors" />}
                <span className="text-[9px] font-bold text-zinc-500 group-hover:text-zinc-400">{label}</span>
            </div>
            {extra}
        </div>
        <div className="flex items-baseline gap-1 mt-1">
             <span className={`text-lg font-mono font-medium leading-none tracking-tight ${color}`}>{value}</span>
             <span className="text-[9px] text-zinc-600 font-bold">{unit}</span>
        </div>
    </div>
);
