import React from 'react';
import { PlatformType, UserRole, LogEntry } from '../types';
import { Power, Crosshair, ArrowUp, ArrowDown, Home, MapPin, Anchor } from 'lucide-react';

interface ControlsPanelProps {
  platform: PlatformType;
  isArmed: boolean;
  userRole: UserRole;
  onArmToggle: () => void;
  onLog: (msg: string, level: LogEntry['level']) => void;
}

export const ControlsPanel: React.FC<ControlsPanelProps> = ({ 
  platform, 
  isArmed, 
  userRole, 
  onArmToggle,
  onLog
}) => {
  const isReadOnly = userRole === UserRole.OBSERVER;

  const handleCommand = (cmd: string) => {
    if(isReadOnly) return;
    onLog(`CMD SENT: ${cmd}`, 'INFO');
  };

  return (
    <div className="flex flex-col gap-2">
        
        {/* Arming Switch Area */}
        <div className={`relative p-1 rounded-sm border-2 ${isArmed ? 'border-red-900 bg-red-900/10' : 'border-zinc-800 bg-zinc-900'}`}>
            {/* Caution Stripes Background if Armed */}
            {isArmed && (
                <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
                    backgroundImage: 'repeating-linear-gradient(45deg, #ef4444 0, #ef4444 10px, transparent 10px, transparent 20px)'
                }} />
            )}

            <button 
                disabled={isReadOnly}
                onClick={onArmToggle}
                className={`w-full h-12 relative overflow-hidden group border transition-all active:scale-[0.98] ${
                    isArmed 
                    ? 'bg-red-600 border-red-500 hover:bg-red-500' 
                    : 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700'
                }`}
            >
                <div className="flex items-center justify-center gap-3 relative z-10">
                    <Power className={`w-5 h-5 ${isArmed ? 'text-white' : 'text-zinc-400 group-hover:text-white'}`} />
                    <span className={`font-bold tracking-widest ${isArmed ? 'text-white' : 'text-zinc-400 group-hover:text-white'}`}>
                        {isArmed ? 'SYSTEM ARMED' : 'DISARMED'}
                    </span>
                </div>
            </button>
        </div>

        {/* Primary Actions Grid */}
        <div className="grid grid-cols-2 gap-2">
            <ControlButton 
                icon={ArrowUp} label="TAKEOFF" 
                onClick={() => handleCommand('TAKEOFF')} 
                disabled={!isArmed || isReadOnly} 
            />
            <ControlButton 
                icon={Home} label="RTL" 
                onClick={() => handleCommand('RTL')} 
                disabled={!isArmed || isReadOnly} 
                accent="amber"
            />
            <ControlButton 
                icon={ArrowDown} label="LAND" 
                onClick={() => handleCommand('LAND')} 
                disabled={!isArmed || isReadOnly} 
            />
            <ControlButton 
                icon={Anchor} label="HOLD" 
                onClick={() => handleCommand('HOLD')} 
                disabled={!isArmed || isReadOnly} 
            />
        </div>

        {/* Mode Selector Panel */}
        <div className="bg-zinc-900 border border-zinc-800 p-2 rounded-sm space-y-2">
            <div className="text-[10px] font-bold text-zinc-500 uppercase border-b border-zinc-800 pb-1 mb-2">
                Flight Modes
            </div>
            <div className="grid grid-cols-2 gap-1">
                {['STABILIZE', 'LOITER', 'AUTO', 'GUIDED'].map(mode => (
                    <button 
                        key={mode}
                        disabled={isReadOnly}
                        onClick={() => handleCommand(`MODE_${mode}`)}
                        className="bg-black border border-zinc-700 text-zinc-400 hover:text-blue-400 hover:border-blue-500 text-[10px] font-bold py-2 px-1 transition-colors"
                    >
                        {mode}
                    </button>
                ))}
            </div>
        </div>
    </div>
  );
};

const ControlButton = ({ icon: Icon, label, onClick, disabled, accent = 'blue' }: any) => {
    const colors = {
        blue: 'hover:bg-blue-900/30 hover:border-blue-500/50 hover:text-blue-400',
        amber: 'hover:bg-amber-900/30 hover:border-amber-500/50 hover:text-amber-400'
    }
    return (
        <button 
            onClick={onClick}
            disabled={disabled}
            className={`
                bg-zinc-900 border border-zinc-800 p-3 flex flex-col items-center justify-center gap-1 rounded-sm transition-all
                disabled:opacity-50 disabled:cursor-not-allowed
                ${!disabled ? (colors[accent as keyof typeof colors] || colors.blue) : ''}
                active:bg-zinc-800
            `}
        >
            <Icon className="w-5 h-5 text-zinc-500" />
            <span className="text-[10px] font-bold text-zinc-300">{label}</span>
        </button>
    )
}