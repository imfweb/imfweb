
import React, { useState } from 'react';
import { Detection, PlatformType, TelemetryData } from '../types';
import { Crosshair, Battery, Monitor, BoxSelect } from 'lucide-react';

interface VideoFeedProps {
  detections: Detection[];
  telemetry: TelemetryData | null;
  platform: PlatformType | undefined;
}

export const VideoFeed: React.FC<VideoFeedProps> = ({ detections, telemetry, platform }) => {
  const [layers, setLayers] = useState({
    reticle: true,
    telemetry: true,
    detections: true
  });

  const toggle = (key: keyof typeof layers) => {
    setLayers(prev => ({ ...prev, [key]: !prev[key] }));
  };
  
  const getBgImage = () => {
    switch (platform) {
        case PlatformType.ROV: 
            return "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?q=80&w=2070&auto=format&fit=crop"; // Underwater
        case PlatformType.USV: 
            return "https://images.unsplash.com/photo-1559136555-9303baea8ebd?q=80&w=2070&auto=format&fit=crop"; // Water Surface
        case PlatformType.QUAD:
            // Updated to match user reference: Aerial view of road with truck/fields
            return "https://images.unsplash.com/photo-1616487820126-7a876a3b2762?q=80&w=1974&auto=format&fit=crop"; 
        case PlatformType.VTOL:
        default: 
            // Updated to resemble aerial hill view
            return "https://images.unsplash.com/photo-1542224566-6e85f2e6772f?q=80&w=1976&auto=format&fit=crop"; 
    }
  }

  return (
    <div className="relative w-full h-full bg-black overflow-hidden select-none group">
      {/* 1. Camera Feed Layer */}
      <img 
        src={getBgImage()} 
        alt="Live Stream" 
        className="w-full h-full object-cover opacity-80"
      />
      
      {/* 2. Interference / Grain */}
      <div className="absolute inset-0 bg-repeat opacity-[0.05] pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'0 0 200 200\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.8\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }}></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/40"></div>

      {/* 3. OSD Controls (Hover to Reveal) */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 transition-all duration-300 opacity-0 -translate-y-4 group-hover:translate-y-0 group-hover:opacity-100">
         <div className="flex items-center gap-1 bg-black/90 backdrop-blur border border-zinc-700 p-1 rounded-sm shadow-2xl">
            <ToggleBtn active={layers.telemetry} onClick={() => toggle('telemetry')} icon={Monitor} label="OSD" />
            <div className="w-px h-3 bg-zinc-800"></div>
            <ToggleBtn active={layers.reticle} onClick={() => toggle('reticle')} icon={Crosshair} label="RET" />
            <div className="w-px h-3 bg-zinc-800"></div>
            <ToggleBtn active={layers.detections} onClick={() => toggle('detections')} icon={BoxSelect} label="AI" />
         </div>
      </div>

      {/* 4. Military OSD (On Screen Display) */}
      <div className="absolute inset-0 z-20 p-4 font-mono text-sm tracking-wide pointer-events-none" style={{ textShadow: '1px 1px 0 #000' }}>
        
        {layers.telemetry && (
          <>
            {/* Top Left: System Status */}
            <div className="absolute top-4 left-4 flex flex-col gap-1 text-white">
                <div className="flex items-center gap-2">
                    <span className="font-bold text-red-500 animate-pulse">REC</span>
                    <span>02:14:59</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-white/90">
                    <span>{platform || 'CAM'}</span>
                    <span>1080P</span>
                    <span className="text-zinc-400">ISO 800</span>
                </div>
            </div>

            {/* Top Right: Power */}
            <div className="absolute top-4 right-4 flex flex-col items-end gap-1 text-white">
                <div className="flex items-center gap-2">
                    <Battery className="w-4 h-4 text-white" />
                    <span className={`font-bold ${(telemetry?.batteryPercent || 0) < 30 ? 'text-red-500' : 'text-white'}`}>
                        {telemetry?.batteryVoltage.toFixed(1)}V
                    </span>
                </div>
                <div className="text-xs text-zinc-400">
                    BAT: {telemetry?.batteryPercent.toFixed(0)}%
                </div>
            </div>

            {/* Bottom Bar: Telemetry */}
            <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end text-white text-xs">
                <div className="flex flex-col gap-0.5">
                    <div>LAT: {telemetry?.latitude.toFixed(6)}</div>
                    <div>LON: {telemetry?.longitude.toFixed(6)}</div>
                </div>
                
                {/* Compass Strip Mockup */}
                <div className="flex-1 mx-8 border-t border-white/30 h-4 relative overflow-hidden flex justify-center pt-1">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-1.5 bg-yellow-400"></div>
                    <div className="flex gap-8 text-[10px] text-white/70">
                        <span>{(telemetry?.heading || 0 - 15 + 360) % 360 | 0}</span>
                        <span>{(telemetry?.heading || 0) | 0}</span>
                        <span>{(telemetry?.heading || 0 + 15) % 360 | 0}</span>
                    </div>
                </div>

                <div className="flex flex-col gap-0.5 text-right">
                    <div className="text-lg font-bold">{telemetry?.altitude.toFixed(1)}m</div>
                    <div className="text-zinc-400">{telemetry?.speed.toFixed(1)} m/s</div>
                </div>
            </div>
          </>
        )}

        {/* Center: Reticle */}
        {layers.reticle && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-70">
              <Crosshair className="w-12 h-12 text-white/80" strokeWidth={1} />
          </div>
        )}

      </div>

      {/* 5. YOLO Overlays */}
      {layers.detections && detections.map((det) => (
        <div
          key={det.id}
          className="absolute z-30 pointer-events-none"
          style={{
            left: `${det.bbox[0] * 100}%`,
            top: `${det.bbox[1] * 100}%`,
            width: `${det.bbox[2] * 100}%`,
            height: `${det.bbox[3] * 100}%`,
          }}
        >
            <div className="w-full h-full border border-lime-400 relative box-border">
                <div className="absolute -top-4 left-0 bg-lime-400/80 text-black text-[9px] font-bold px-1">
                    {det.label} {(det.confidence * 100).toFixed(0)}%
                </div>
            </div>
        </div>
      ))}
    </div>
  );
};

const ToggleBtn = ({ active, onClick, icon: Icon, label }: any) => (
  <button 
    onClick={onClick}
    className={`
      flex items-center gap-1.5 px-2 py-1.5 rounded-[2px] text-[10px] font-bold border transition-all pointer-events-auto
      ${active 
        ? 'bg-blue-500/20 border-blue-500 text-blue-400 hover:bg-blue-500/30' 
        : 'bg-zinc-800/50 border-zinc-700 text-zinc-500 hover:bg-zinc-800 hover:text-zinc-300'
      }
    `}
  >
    <Icon className="w-3 h-3" />
    <span>{label}</span>
  </button>
);
