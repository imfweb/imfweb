
export enum UserRole {
  ADMIN = 'ADMIN',
  PILOT = 'PILOT',
  OBSERVER = 'OBSERVER'
}

export enum PlatformType {
  VTOL = 'VTOL',
  QUAD = 'QUAD',
  USV = 'USV',
  ROV = 'ROV'
}

export interface TelemetryData {
  latitude: number;
  longitude: number;
  altitude: number; // meters
  heading: number; // 0-360
  speed: number; // m/s
  roll: number;
  pitch: number;
  yaw: number;
  batteryVoltage: number;
  batteryPercent: number;
  satellites: number;
  rssi: number; // Signal strength dBm
  mode: string;
  armed: boolean;
  timestamp: number;
}

export interface Vehicle {
  id: string;
  name: string;
  type: PlatformType;
  telemetry: TelemetryData;
  status: 'ONLINE' | 'OFFLINE' | 'WARN';
}

export interface Detection {
  id: string;
  label: string;
  confidence: number;
  bbox: [number, number, number, number]; // [x, y, width, height] normalized 0-1
  timestamp: number;
}

export interface LogEntry {
  id: string;
  timestamp: number;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';
  message: string;
}

export interface Waypoint {
  id: string;
  latitude: number;
  longitude: number;
  altitude: number; // Relative altitude in meters
  order: number;
}
